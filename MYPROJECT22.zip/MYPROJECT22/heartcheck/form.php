<?php
session_start(); // Start the session
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Heart Diagnosis Form</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .form-container {
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            max-width: 500px;
            width: 100%;
        }

        .sec{
            display: flex;
          
            gap: 50px;
        }
        h2 {
            text-align: center;
            color: #333;
        }

        label {
            display: block;
            margin-bottom: 5px;
        }

        input[type="number"],
        select {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }

        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            padding: 14px 20px;
            margin: 8px 0;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            width: 100%;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>  
    <div class="form-container">
        <a href="Dashboard.php">back</a>
        <h2>Heart Diagnosis Form</h2>
        <form action="new.php" method="post">
            <div class="sec">
            <div class="sec1">
            <label for="age">Age:</label>
            <input type="number" id="age" name="age" required>
            
            <label for="sex">Sex:</label>
            <select id="sex" name="sex" required>
                <option value="1">Male</option>
                <option value="0">Female</option>
            </select>
            
            <label for="cp">Chest Pain Level:</label>
            <select id="cp" name="cp" required>
                <option value="0">No Chest Pain</option>
                <option value="1">High</option>
                <option value="2">Average</option>
                <option value="3">Low</option>
            </select>
            
            <label for="trestbps">Resting Blood Pressure:</label>
            <input type="number" id="trestbps" name="trestbps" required>
            
            <label for="chol">Serum Cholesterol:</label>
            <select id="chol" name="chol" required>
                <option value="0">No</option>
                <option value="1">Yes</option>
            </select>
            
            <label for="fbs">Fasting Blood Sugar &gt; 120 mg/dl:</label>
            <select id="fbs" name="fbs" required>
                <option value="0">No</option>
                <option value="1">Yes</option>
            </select>
            </div>

            <div class="sec2">
            <label for="restecg">Resting Electrocardiographic Results:</label>
            <input type="number" id="restecg" name="restecg" required>
            
            <label for="thalach">Maximum Heart Rate Achieved:</label>
            <input type="number" id="thalach" name="thalach" required>
            
            <label for="exang">Exercise Induced Angina:</label>
            <select id="exang" name="exang" required>
                <option value="0">No</option>
                <option value="1">Yes</option>
            </select>
            
            <label for="oldpeak">ST Depression Induced by Exercise Relative to Rest:</label>
            <select id="oldpeak" name="oldpeak" required>
                <option value="0.0">0.0</option>
                <option value="0.1">0.1</option>
                <option value="0.2">0.2</option>
                <!-- Add other options as needed -->
            </select>
            
            <label for="slope">Slope of the Peak Exercise ST Segment:</label>
            <select id="slope" name="slope" required>
                <option value="0">Upsloping</option>
                <option value="1">Flat</option>
                <option value="2">Downsloping</option>
            </select>
            
            <label for="ca">Number of Major Vessels Colored by Fluoroscopy:</label>
            <select id="ca" name="ca" required>
                <option value="0">0</option>
                <option value="1">1</option>
                <option value="2">2</option>
                <option value="3">3</option>
            </select>
            
            <label for="thal">Thalassemia:</label>
            <select id="thal" name="thal" required>
                <option value="0">Normal</option>
                <option value="1">Fixed defect</option>
                <option value="2">Reversible defect</option>
                <option value="3">No thalassemia detected or other</option>
            </select>
            </div>
            </div>
            
            <input type="submit" value="Submit">
        </form>
    
    
  <?php if (isset($_SESSION['prediction'])): ?>
        <p>
            <?php
            if ($_SESSION['prediction'] == 1) {
                echo "Based on the provided data, the prediction is: Heart Attack Likely";
            } else {
                echo "Based on the provided data, the prediction is: No Heart Attack";
            }
            ?>
        </p>
        <?php
        // Unset the session variable to clear the prediction result
        unset($_SESSION['prediction']);
        ?>
    <?php endif; ?>
</div>
</body>
</html>
