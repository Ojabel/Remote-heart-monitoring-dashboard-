<?php
$servername = "localhost"; // Replace with your server name
$username = "root"; // Replace with your database username
$password = ""; // Replace with your database password
$dbname = "projecttest"; // Replace with your database name

if(isset($_POST['heartRate']) && isset($_POST['id'])){
// Retrieve heart rate data from the POST request
$boardid = $_POST['id'];
$heartRate = $_POST['heartRate'];


// Create a connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check the connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if the ID already exists in the database
$sql = "SELECT * FROM health_data WHERE id = '$boardid'";
$result = mysqli_query($conn, $sql);


if (mysqli_num_rows($result) > 0) {
    // ID exists, update the heart rate data
    $sql = "UPDATE health_data SET heart_rate = '$heartRate' WHERE id = '$boardid'";
} else {
    // ID does not exist, insert the heart rate data
    $sql = "INSERT INTO health_data (heart_rate, id) VALUES ('$heartRate', '$boardid')";
}

// Execute the SQL statement
if (mysqli_query($conn, $sql)) {
    echo "Heart rate data inserted/updated successfully";
} else {
    echo "Error inserting/updating heart rate data: " . mysqli_error($conn);
}

// Close the connection
mysqli_close($conn);
}
?>




