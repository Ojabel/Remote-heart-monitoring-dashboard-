
function fetchAllData() {
    fetch('get_all_data.php')
      .then(response => response.json())
      .then(data => {	
        document.getElementById('userData').innerHTML = '';
        data.forEach(user => {
          document.getElementById('userData').innerHTML += `
            <div class="user-data">
              <h2>User ID: ${user.id}</h2>
              <p>Username: ${user.username}</p>
              <p>Temperature: ${user.temperature}</p>
              <p>Heart Rate: ${user.heartRate}</p>
            </div>
          `;
        });
      })
      .catch(error => console.error('Error fetching data:', error));
  }
  
  setInterval(fetchAllData, 5000);
  

  window.onload = fetchAllData;
  
  
  
  
  
  
  
  
  