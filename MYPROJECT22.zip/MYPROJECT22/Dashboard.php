


<?php
require_once 'db.php';
session_start();

if (!isset($_SESSION["username"])) {
    header("Location: login.html");
    exit();
}

$username = $_SESSION["username"];


$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Health Monitoring Dashboard</title>
    <link rel="icon" type="image/png" href="image/bg1.jpg">
    <link rel="stylesheet" href="Style.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        /* Add your additional CSS styling here */
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
        }

        h1 {
            text-align: center;
            margin: 20px 5px;
            background-color: #0c6980;
            color: #ffffff;
            display: flex;
            justify-content: space-between;
            padding: 10px;
            border-radius: 5px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
        }

        h1 a {
            text-decoration: none;
            font-size: 18px;
            color:  #0c6980;
            margin-right: 20px;
            padding: 10px;
            background-color: whitesmoke;
            border-radius: 20px;
            cursor: pointer;
        }

        h1 label {
            padding: 10px;
        }

        .container {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            padding: 10px;
            border-bottom: 1px solid #ddd;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        .hdata a {
            display: block;
            text-align: center;
            margin-top: 20px;
            padding: 10px;
            background-color: #0c6980;
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        .hdata a:hover {
            background-color: #08586d;
        }
        .graphcontainer{
          
            max-width: 80%;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border: 1px solid #ccc;
           
        }
       
        
@media (max-width: 650px) {
        h1 label {
            font-size: smaller;
        }
      
}
    </style>
</head>
<body>
    <h1>
        <label>Welcome, <?php echo $username; ?> </label>
        <a href="#" onclick="logout()">Logout</a>
    </h1>
    <div class="container" id="userData">
        <!-- Health data table will be loaded here -->
    </div>
    
    <div class="hdata">
        <a href="user_recordtable.php">See all Health Data</a>
    </div>
    <div class="hdata">
        <a href="heartcheck/form.php">check heart condition</a>
    </div>

    <script>
        function logout() {
            if (confirm("Are you sure you want to logout?")) {
                window.location.href = "logout.php";
            }
        }

        function fetchHealthData() {
            fetch('get_health_data.php')
                .then(response => response.json())
                .then(data => {
                    const userData = document.getElementById('userData');
                    userData.innerHTML = `
                        <h2>Health Data</h2>
                        <table>
                            <tr>
                                <th>Name</th>
                                <th>Temperature</th>
                                <th>Heart Rate</th>
                            </tr>
                            ${data.map(user => `
                                <tr>
                                    <td>${user.username}</td>
                                    <td>${user.temperature}</td>
                                    <td>${user.heartRate}</td>
                                </tr>
                            `).join('')}
                        </table>
                    `;
                })
                .catch(error => console.error('Error fetching data:', error));
        }

        
        fetchHealthData();
     setInterval(fetchHealthData, 5000);
    </script>

<div class="graphcontainer" >
    <canvas id="healthChart"></canvas>
</div>
<script>
    // Create initial empty datasets
    let timeData = [];
    let temperatureData = [];
    let heartRateData = [];

    // Function to fetch health data from the server and update the chart
    function updateChart() {
        fetch('graph.php')
            .then(response => response.json())
            .then(data => {
                // Process the data
                timeData = data.map(entry => entry.time);
                temperatureData = data.map(entry => entry.temperature);
                heartRateData = data.map(entry => entry.heartRate);

                // Update the chart data
                healthChart.data.labels = timeData;
                healthChart.data.datasets[0].data = temperatureData;
                healthChart.data.datasets[1].data = heartRateData;
                healthChart.update({
                    preservation: true // Preserve the existing chart options (e.g., axes range)
                });
            })
            .catch(error => console.error('Error fetching health data:', error));
    }

    // Create the initial chart
    const ctx = document.getElementById('healthChart').getContext('2d');
    const healthChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: timeData,
            datasets: [{
                label: 'Temperature',
                data: temperatureData,
                backgroundColor: 'rgba(255, 99, 132, 0.5)',
                borderColor: 'rgba(255, 99, 132, 1)',
                borderWidth: 1
            }, {
                label: 'Heart Rate',
                data: heartRateData,
                backgroundColor: 'rgba(54, 162, 235, 0.5)',
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                xAxes: [{
                    type: 'time',
                    time: {
                     
                    },
                    scaleLabel: {
                        display: true,
                        labelString: 'Time'
                    }
                }],
                yAxes: [{
                    scaleLabel: {
                        display: true,
                        labelString: 'Value'
                    }
                }]
            }
        }
    });

    // Fetch data and update chart every 5 seconds
    setInterval(updateChart, 5000);
</script>


</body>
</html>
