<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Health Monitoring System</title>
   
    <style>
        /* Reset default browser styles */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: Arial, sans-serif;
}

header {
    background-color: #007bff;
    color: #fff;
    padding: 20px;
}

.logo{
    display: flex;
    justify-content: center;
}

.logo img {
    width: 150px; /* Adjust as needed */
}

.logo label{
    position: relative;
    top: 30px;
    left: 5px;
}

.cta-buttons button {
    margin-left: 10px;
    padding: 10px 20px;
    background-color: #fff;
    color: #007bff;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    transition: background-color 0.3s ease;
}

.cta-buttons button:hover {
    background-color: #e3e3e3;
}

.hero {
    background-image: url('image/bg2.jpg');
    background-size: cover;
    color: #fff;
    text-align: center;
    padding: 100px 20px;
}

.hero-content {
    max-width: 600px;
    margin: 0 auto;
}


.hero-content button {
    padding: 10px 20px;
    background-color: #fff;
    color: #007bff;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    margin-top: 10px;
    font-size: 1em;
    font-weight: bolder;
}
.features {
    display: flex;
    justify-content: center;
    align-items: flex-start;
    gap: 20px;
    padding: 50px 20px;
}

.feature {
    text-align: center;
}

.feature img {
    width: 150px;
}


.call-to-action {
    background-image: url('image/bg1.jpg');
    background-size: cover;
    color: #fff;
    text-align: center;
    padding: 100px 20px;
}

.cta-content {
    max-width: 600px;
    margin: 0 auto;
}

.cta-content h2 {
    margin-bottom: 20px;
}

.cta-content button {
    padding: 15px 30px;
    background-color: #007bff;
    color: #fff;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    transition: background-color 0.3s ease;
}

.cta-content button:hover {
    background-color: #0056b3;
}

footer {
    background-color: #333;
    color: #fff;
    text-align: center;
    padding: 20px;
}

    </style>
</head>
<body>
    <header>
        <!-- Navigation Menu and Logo -->
        <nav>
            <!-- Navigation Links -->
        </nav>
        <div class="logo">
            <img src="image/headlogo.png" alt="Health Monitoring System Logo">
            <label>OJTECH HEALTH MONIORING SYSEM</label>

        </div>
        <div class="cta-buttons">
            <button>Sign In</button>
            <button>Sign Up</button>
        </div>
    </header>

    <section class="hero">
        <div class="hero-content">
            <h1>Track Your Health, Stay Informed</h1>
            <p>Monitor vital signs, track activities, and achieve your wellness goals with our cutting-edge health monitoring system.</p>
            <button>Get Started</button>
        </div>
    </section>

    <section class="features">
        <div class="feature">
            <img src="image/sychronize.png" alt="Sync Your Device">
            <h3>Sync Your Device</h3>
            <p>Connect your health monitoring device with our web application seamlessly.</p>
        </div>
        <div class="feature">
            <img src="image/hrtbt.png" alt="Monitor Your Health">
            <h3>Monitor Your Health</h3>
            <p>Keep an eye on your vital signs and activities in real-time.</p>
         </div>
        <div class="feature">
            <img src="image/analyze.png" alt="Analyze Your Data">
            <h3>Analyze Your Data</h3>
            <p>Review detailed insights and trends to make informed decisions about your health.</p>
         </div>
    </section>


  

    <section class="call-to-action">
        <div class="cta-content">
            <h2>Join Thousands of Users Taking Control of Their Health Today!</h2>
            <button>Sign Up Now</button>
        </div>
    </section>

    <footer>
        <!-- Footer Section -->
    </footer>
</body>
</html>
