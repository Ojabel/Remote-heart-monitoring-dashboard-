<?php
// Assume $currentTemperature and $currentHeartRate contain the current sensor readings

// Make a prediction using the trained model
$prediction = $model->predict([$currentTemperature, $currentHeartRate]);

// Display the prediction in your dashboard
echo "Predicted Health Condition: " . $prediction;
?>
