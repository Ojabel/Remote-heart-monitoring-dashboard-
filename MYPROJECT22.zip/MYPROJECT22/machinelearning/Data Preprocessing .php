<?php
require_once 'db.php';

// Fetch health data from the database
$sql = "SELECT temperature, heart_rate FROM user_health_record WHERE username='$username'";
$result = $conn->query($sql);

// Initialize arrays to store features and labels
$features = [];
$labels = [];

// Process retrieved data
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        // Extract features (temperature, heart rate)
        $temperature = $row["temperature"];
        $heartRate = $row["heart_rate"];
        
        // Store features and labels
        $features[] = [$temperature, $heartRate];
        // You need to define labels based on your use case
        $labels[] = ...;
    }
}

// Close the database connection
$conn->close();
?>
