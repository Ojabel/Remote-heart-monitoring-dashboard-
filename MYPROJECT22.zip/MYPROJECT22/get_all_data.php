<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "projecttest";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Fetch all users' health data
$sql = "SELECT id, username, temperature, heart_rate FROM health_data";
$result = $conn->query($sql);
$data = array();

if ($result->num_rows > 0) {
  while($row = $result->fetch_assoc()) {
    $data[] = array(
      'id' => $row['id'],
      'username' => $row['username'],
      'temperature' => $row['temperature'],
      'heartRate' => $row['heart_rate']
    );
  }
}

echo json_encode($data);
$conn->close();
?>

