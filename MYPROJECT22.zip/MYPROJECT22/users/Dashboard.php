


<?php
require_once 'db.php';
session_start();

if (!isset($_SESSION["username"])) {
    header("Location: login.html");
    exit();
}

$username = $_SESSION["username"];


$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Health Monitoring Dashboard</title>
    <link rel="icon" type="image/png" href="images/bg1.jpg">
    <link rel="stylesheet" href="Style.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        /* Add your additional CSS styling here */
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
        }

        h1 {
            text-align: center;
            margin: 20px 5px;
            background-color: #0c6980;
            color: #ffffff;
            display: flex;
            justify-content: space-between;
            padding: 10px;
            border-radius: 5px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
        }

        h1 a {
            text-decoration: none;
            font-size: 18px;
            color:  #0c6980;
            margin-right: 20px;
            padding: 10px;
            background-color: whitesmoke;
            border-radius: 20px;
            cursor: pointer;
        }

        h1 label {
            padding: 10px;
        }

        .container {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            padding: 10px;
            border-bottom: 1px solid #ddd;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        .hdata a {
            display: block;
            text-align: center;
            margin-top: 20px;
            padding: 10px;
            background-color: #0c6980;
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        .hdata a:hover {
            background-color: #08586d;
        }
    </style>
</head>
<body>
    <h1>
        <label>Welcome, <?php echo $username; ?> </label>
        <a href="#" onclick="logout()">Logout</a>
    </h1>
    <div class="container" id="userData">
        <!-- Health data table will be loaded here -->
    </div>
    
    <div class="hdata">
        <a href="user_recordtable.php">See all Health Data</a>
    </div>

    <script>
        function logout() {
            if (confirm("Are you sure you want to logout?")) {
                window.location.href = "logout.php";
            }
        }

        function fetchHealthData() {
            fetch('get_health_data.php')
                .then(response => response.json())
                .then(data => {
                    const userData = document.getElementById('userData');
                    userData.innerHTML = `
                        <h2>Health Data</h2>
                        <table>
                            <tr>
                                <th>Name</th>
                                <th>Temperature</th>
                                <th>Heart Rate</th>
                            </tr>
                            ${data.map(user => `
                                <tr>
                                    <td>${user.username}</td>
                                    <td>${user.temperature}</td>
                                    <td>${user.heartRate}</td>
                                </tr>
                            `).join('')}
                        </table>
                    `;
                })
                .catch(error => console.error('Error fetching data:', error));
        }

        
        fetchHealthData();
     setInterval(fetchHealthData, 5000);
    </script>

<div class="container" id="userData">
        <canvas id="healthChart"></canvas>
    </div>
    <script>
        // Function to fetch health data from the server
        function fetchHealthData() {
            fetch('graph.php')
                .then(response => response.json())
                .then(data => {
                    // Process the data
                    const time = data.map(entry => entry.time);
                    const temperatures = data.map(entry => entry.temperature);
                    const heartRates = data.map(entry => entry.heartRate);

                    // Create a chart
                    const ctx = document.getElementById('healthChart').getContext('2d');
                    const healthChart = new Chart(ctx, {
                        type: 'bar',
                        data: {
                            labels: time,
                            datasets: [{
                                label: 'Temperature',
                                data: temperatures,
                                backgroundColor: 'rgba(255, 99, 132, 0.5)',
                                borderColor: 'rgba(255, 99, 132, 1)',
                                borderWidth: 1
                            }, {
                                label: 'Heart Rate',
                                data: heartRates,
                                backgroundColor: 'rgba(54, 162, 235, 0.5)',
                                borderColor: 'rgba(54, 162, 235, 1)',
                                borderWidth: 1
                            }]
                        },
                     
                    });
                })
                .catch(error => console.error('Error fetching health data:', error));
        }

       
        window.onload = fetchHealthData;
    </script>
</body>
</html>
