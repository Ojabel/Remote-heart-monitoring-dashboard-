<?php
require_once 'db.php';
session_start();

if (!isset($_SESSION["username"])) {
    http_response_code(401); // Unauthorized
    exit("Unauthorized");
}

$username = $_SESSION["username"];


$sql = "SELECT * FROM health_data WHERE username='$username'";
$result = $conn->query($sql);

if (!$result) {
    http_response_code(500); // Internal Server Error
    exit("Error: " . $conn->error);
}

$data = [];

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $data[] = [
            "username" => $row["username"],
            "temperature" => $row["temperature"],
            "heartRate" => $row["heart_rate"]
        ];
    }
}

$conn->close();

header("Content-Type: application/json");
echo json_encode($data);
?>
