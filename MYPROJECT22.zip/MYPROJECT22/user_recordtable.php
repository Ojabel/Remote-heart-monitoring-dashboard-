<?php
require_once 'db.php';
session_start();

if (!isset($_SESSION["username"]) ) {

    header("Location: index.html");
    exit();
}

$username = $_SESSION["username"];


$sql = "SELECT * FROM user_health_record WHERE username = ? ORDER BY time DESC"; // Modify query to order by time in descending order
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();

if (!$result) {
    die("Error retrieving data: " . $conn->error);
}

?>

<!DOCTYPE HTML>
<html>
<head>
    <title>Patient Health Data Records</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        html {
            font-family: Arial, sans-serif;
            display: inline-block;
            text-align: center;
        }

        body {
            margin: 0;
            padding: 0;
            background-color: #f2f2f2;
        }

        .topnav {
            overflow: hidden;
            background-color: #0c6980;
            color: white;
            font-size: 1.2rem;
            padding: 10px 0;
            display: grid;
            justify-content: center;
        }

        .topnav h3 {
            margin: 0;
            text-align: left;
        }

        .topnav a {
            text-decoration: none;
            color: whitesmoke;
            margin-right: 20px;
            padding: 10px;
            background-color: #094c5d;
            border-radius: 5px;
        }

        .container {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
        }

        .styled-table {
            border-collapse: collapse;
            width: 100%;
            font-size: 0.9em;
            font-family: sans-serif;
        }

        .styled-table th,
        .styled-table td {
            border: 1px solid #ddd;
            padding: 8px;
        }

        .styled-table th {
            background-color: #0c6980;
            color: white;
            text-align: left;
        }

        .styled-table tbody tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        .styled-table tbody tr:hover {
            background-color: #ddd;
        }

        .btn-group {
            margin-top: 20px;
        }

        .button {
            background-color: #0c6980;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1rem;
            margin-right: 10px;
        }

        .button:hover {
            background-color: #094c5d;
        }

        select {
            padding: 10px;
            font-size: 1rem;
        }
    </style>
</head>

<body>
<div class="topnav">
    <h3>Patient Health Data Records</h3>
    <a href="Dashboard.php">Back to Dashboard</a>
</div>

<div class="container">
    <h3>Health Data Records Table</h3>
    <table class="styled-table">
        <thead>
        <tr>
            <th>Board ID</th>
            <th>Name</th>
            <th>Temperature (°C)</th>
            <th>Heart Rate</th>
            <th>Time</th>
        </tr>
        </thead>
    <tbody id="tbody_table_record">
    <?php
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo '<tr>';
            echo '<td>' . $row['id'] . '</td>';
            echo '<td class="bdr">' . $row['username'] . '</td>';
            echo '<td class="bdr">' . $row['temperature'] . '</td>';
            echo '<td class="bdr">' . $row['heart_rate'] . '</td>';
            echo '<td class="bdr">' . $row['time'] . '</td>';
            echo '</tr>';
        }
    } else {
        echo '<tr><td colspan="5">No records found for this user</td></tr>';
    }
    ?>
    </tbody>
</table>
    </table>
    
    <div class="btn-group">
        <button class="button" id="btn_prev" onclick="prevPage()">Prev</button>
        <button class="button" id="btn_next" onclick="nextPage()">Next</button>
        <span>Page: <span id="page"></span></span>
        <select name="number_of_rows" id="number_of_rows">
            <option value="10">10</option>
            <option value="25">25</option>
            <option value="50">50</option>
            <option value="100">100</option>
        </select>
        <button class="button" id="btn_apply" onclick="applyNumberOfRows()">Apply</button>
    </div>
</div>
    <script>
      //------------------------------------------------------------
      var current_page = 1;
      var records_per_page = 10;
      var l = document.getElementById("table_id").rows.length
      //------------------------------------------------------------
      
      //------------------------------------------------------------
      function apply_Number_of_Rows() {
        var x = document.getElementById("number_of_rows").value;
        records_per_page = x;
        changePage(current_page);
      }
      //------------------------------------------------------------
      
      //------------------------------------------------------------
      function prevPage() {
        if (current_page > 1) {
            current_page--;
            changePage(current_page);
        }
      }
      //------------------------------------------------------------
      
      //------------------------------------------------------------
      function nextPage() {
        if (current_page < numPages()) {
            current_page++;
            changePage(current_page);
        }
      }
      //------------------------------------------------------------
      
      //------------------------------------------------------------
      function changePage(page) {
        var btn_next = document.getElementById("btn_next");
        var btn_prev = document.getElementById("btn_prev");
        var listing_table = document.getElementById("table_id");
        var page_span = document.getElementById("page");
       
        // Validate page
        if (page < 1) page = 1;
        if (page > numPages()) page = numPages();

        [...listing_table.getElementsByTagName('tr')].forEach((tr)=>{
            tr.style.display='none'; // reset all to not display
        });
        listing_table.rows[0].style.display = ""; // display the title row

        for (var i = (page-1) * records_per_page + 1; i < (page * records_per_page) + 1; i++) {
          if (listing_table.rows[i]) {
            listing_table.rows[i].style.display = ""
          } else {
            continue;
          }
        }
          
        page_span.innerHTML = page + "/" + numPages() + " (Total Number of Rows = " + (l-1) + ") | Number of Rows : ";
        
        if (page == 0 && numPages() == 0) {
          btn_prev.disabled = true;
          btn_next.disabled = true;
          return;
        }

        if (page == 1) {
          btn_prev.disabled = true;
        } else {
          btn_prev.disabled = false;
        }

        if (page == numPages()) {
          btn_next.disabled = true;
        } else {
          btn_next.disabled = false;
        }
      }
      //------------------------------------------------------------
      
      //------------------------------------------------------------
      function numPages() {
        return Math.ceil((l - 1) / records_per_page);
      }
      //------------------------------------------------------------
      
      //------------------------------------------------------------
      window.onload = function() {
        var x = document.getElementById("number_of_rows").value;
        records_per_page = x;
        changePage(current_page);
      };
      //------------------------------------------------------------
    </script>
  </body>
</html>
