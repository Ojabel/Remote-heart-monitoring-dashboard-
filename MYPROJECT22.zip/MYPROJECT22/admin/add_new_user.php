<?php
require_once 'db.php';


$username = "username";

				$query = mysqli_query($conn, "SELECT  id FROM user_health_record ORDER BY id DESC") ;

				$fetch = mysqli_fetch_array($query);
	?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add User</title>
    <link rel="icon" type="image/png" href="images/bg1.jpg">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            
        }
        h2{
            text-align: center;
            font-size: 35px;
            color: white;
            background-color: #06041d;
            padding: 15px;
            border: none;
            height: 60px;
            border-radius: 5px;
            max-width: 300%;
            margin-bottom: 30px;
            display: grid;
            
        }
        h2 a{
            text-decoration: none;
            color: blue;
            padding: 10px;
        }

        form {
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            background-color: #fff;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
        }

        label {
            display: block;
            margin-bottom: 20px;
            position: relative;
            top: 15px;
            color: green;
        }

        input[type="text"], input[type="email"], input[type="number"],
        input[type="password"] {
            width: 100%;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
            margin-bottom: 20px;
        }

        button[type="submit"] {
            width: 100%;
            padding: 10px;
            background-color: #4CAF50;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        button[type="submit"]:hover {
            background-color: #45a049;
        }
        .table{
            display: flex;
            justify-content: space-between;
            gap: 50px;
        }


        @media (max-width: 900px) {
            .nav{
    background-color: #06041d;
    height: 30px;
    width: 100%;
    margin-bottom: 10px;
}
            .table{
            display: grid;
            justify-content: center;
            gap: 50px;
           
        }
        
        form {
            max-width: 300px;
            margin: 0 auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            background-color: #fff;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
            position: relative;
            left: 30px;
        }

        h2{
            display: none;
        }
        }



    </style>
</head>
<?php include 'sidebar.php'; ?>
<body>
    <div class="nav"></div>

    <h2>Add User</h2>
 
        <form action="adduser.php" method="post" enctype="multipart/form-data">
        <p>board id-no:  <?php echo $fetch['id']+1?></p>
        <div class="table">
            <div class="tbl">
            <label for="boardid">boardid</label>
            <input type="number" id="username" name="boardid" required>
            <br>
            <label for="Full name">Full name</label>
            <input type="text" id="Fname" name="Fname" required>
            <br>
            <label for="username">Username</label>
            <input type="text" id="username" name="username" required>
            <br>
            <label for="Email">Email</label>
            <input type="email" id="email" name="email" required>
            <br>
            </div>
            <div class="tbll">
            <label for="age">Age</label>
            <input type="number" id="age" name="age" required>
            <br>
            <label for="age">Gender</label>
            <input type="text" id="sex" name="sex" required>
            <br>
            <label for="contact">Contact</label>
            <input type="text" id="contact" name="contact" required>
            <br>
            <label for="address">Address</label>
            <input type="text" id="address" name="address" required>
            <br>
            <label for="password">Password</label>
            <input type="password" id="password" name="password" required>
            <br>
            </div>
            </div>
            <label for="image">User Image</label>
            <input type="file" name="image">
                <br>
                <br>
            <button type="submit">Add</button>
        </form>
    

        <script>
            
        </script>
</body>

</html>



