<?php
// Check if the request method is POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    // Check if all required fields are present
    if (isset($_POST["heartRate"]) && isset($_POST["bloodSugar"]) && isset($_POST["username"]) && isset($_POST["boardid"])) {
        
        // Assign POST data to variables
        $heartRate = $_POST["heartRate"];
        $bloodSugar = $_POST["bloodSugar"];
        $username = $_POST["username"];
        $boardid = $_POST["boardid"];

        // Connect to your MySQL database
        $conn = new mysqli("localhost", "your_username", "your_password", "your_database_name");

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Check if the record for the boardid already exists
        $sql = "SELECT * FROM your_table_name WHERE boardid = '$boardid'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // Update existing record
            $sql_update = "UPDATE your_table_name SET heartRate='$heartRate', bloodSugar='$bloodSugar', username='$username' WHERE boardid='$boardid'";
            if ($conn->query($sql_update) === TRUE) {
                echo "Record updated successfully";
            } else {
                echo "Error updating record: " . $conn->error;
            }
        } else {
            // Insert new record
            $sql_insert = "INSERT INTO your_table_name (heartRate, bloodSugar, username, boardid) VALUES ('$heartRate', '$bloodSugar', '$username', '$boardid')";
            if ($conn->query($sql_insert) === TRUE) {
                echo "New record inserted successfully";
            } else {
                echo "Error inserting record: " . $conn->error;
            }
        }

        $conn->close(); // Close the database connection
    } else {
        echo "Missing required fields";
    }
} else {
    echo "Invalid request method";
}
?>
