CREATE TABLE health_records (
    id INT AUTO_INCREMENT PRIMARY KEY,
    heartRate INT,
    bloodSugar FLOAT,
    username VARCHAR(255),
    boardid INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
