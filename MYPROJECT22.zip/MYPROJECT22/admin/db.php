<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "projecttest";

// Create a connection
$conn = mysqli_connect($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
// Die if connection was not successful
?>