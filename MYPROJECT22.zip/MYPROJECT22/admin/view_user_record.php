<?php
require_once 'db.php';

// Check if the username is provided in the URL
if (!isset($_GET['username'])) {
    http_response_code(400); // Bad Request
    exit("Username not provided");
}

$username = $_GET['username'];
// Fetch all user data from the user_health_record table
$sql = "SELECT * FROM user_health_record where username='$username' order by time desc";
$result = $conn->query($sql);

if (!$result) {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>User Health Records</title>
  <link rel="icon" type="image/png" href="images/bg1.jpg">
  <link rel="stylesheet" href="loader.css">
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f0f0f0;
      padding: 20px;
    }

    .link{
        text-align: center;
    }
    .link a{
        color: whitesmoke;
        background-color: #2a2185;;
        padding: 10px;
        border-radius: 5px;
        text-decoration: none;
    }
    h1 {
      text-align: center;
      margin-bottom: 20px;
    }

    .topnav {
            overflow: hidden;
            background-color: #0c6980;
            color: white;
            font-size: 1.2rem;
            padding: 10px 0;
            display: grid;
            justify-content: center;
        }

        .topnav h3 {
            margin: 0;
            text-align: left;
        }

        .topnav a {
            text-decoration: none;
            color: whitesmoke;
            margin-right: 20px;
            padding: 10px;
            background-color: #094c5d;
            border-radius: 5px;
            text-align: center;
        }

        .container {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
        }

        .styled-table {
            border-collapse: collapse;
            width: 100%;
            font-size: 0.9em;
            font-family: sans-serif;
        }

        .styled-table th,
        .styled-table td {
            border: 1px solid #ddd;
            padding: 8px;
        }

        .styled-table th {
            background-color: #0c6980;
            color: white;
            text-align: left;
           
        }

        .styled-table tbody tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        .styled-table tbody tr:hover {
            background-color: #ddd;
        }

        .btn-group {
            margin-top: 20px;
        }

        .button {
            background-color: #0c6980;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1rem;
            margin-right: 10px;
        }

        .button:hover {
            background-color: #094c5d;
        }

        select {
            padding: 10px;
            font-size: 1rem;
        }
    
    .contact-address-table {
      width: 100%;
      border-collapse: collapse;
    }

    .contact-address-table th, .contact-address-table td {
      padding: 10px;
      text-align: left;
      border: none;
    }

    .contact-address-table th {
      background-color: #f2f2f2;
    }

    .contact-address-table td {
      background-color: #fff;
      font-weight: bold;
    }
    .user-image{
 display: block;
 margin: 0 auto;
 width: 200px;
      height: 200px;
      border-radius: 0;
      border: 2px solid #ccc;
    }

    #info tr td{
      display: grid;
      justify-content: center;      
    }
    
  
    @media (max-width: 500px) {
            .link{
            font-size: small;  
        }
        h1{
          font-size:0.9em;
        }
      
      .contact-address-table thead{
       display: none;
   
    }
     .data-table {
      width: 100%;
      font-size: small;
    }
    .user-image{
       display: block;
        margin: 0 auto;
        width: 150px;
      height: 150px;
      border-radius: 0;
      border: 2px solid #ccc;
      margin-bottom: 10px;
    }
    
    #info tr td{
      display: grid;
      justify-content: center;      
    }
    .styled-table th {
           
            font-size: x-small;
        }
        #tbody_table_record{
          font-size: smaller;
        }
    
    }
  </style>
  <script>
    window.addEventListener("load", () =>{
        const loader = document.querySelector(".loader");
    loader.classList.add("loader--hidden");
    loader.addEventListener("transitinend", () =>{
        document.body.removeChild(loader);
    })
 });
</script>
</head>

<body>
<div class="loader "></div>
<div class="topnav">
    <h3>Patient Health Data Records</h3>
    <a href="Dashboard.php">Back to Dashboard</a>

</div>

  <table class="contact-address-table">

    <tbody id="info">
      <tr >
        <?php

$sql = "SELECT * FROM `users` WHERE username='$username'";
$result1 = $conn->query($sql);

if ($result1->num_rows > 0) {
          while ($row = $result1->fetch_assoc()) {

              echo "<tr>";
              if (!empty($row['image_data'])) {
                echo '<img src="data:image/jpeg;base64,'.base64_encode($row['image_data']).'" class="user-image"/>';
            } else {
                echo "No image available";
            }    
            echo "<td>"."Full Name:  " . $row["Fname"] . "</td>";
            echo "<td>"."Gender:  " . $row["Sex"] . "</td>";
            echo "<td>"."Age:  " . $row["Age"] . "</td>";
              echo "<td>"."Email:  " . $row["email"] . "</td>";
              echo "<td>" ."Contact:  ". $row["contact"] . "</td>";
              echo "<td>" ."Address:  ". $row["address"] . "</td>";
              echo "</tr>";
          }
       }
      ?>
        
      </tr>
    </tbody>
  </table>

  <div class="container">
    <h3>Health Data Records Table</h3>
    <table class="styled-table">
        <thead>
        <tr>
            <th>Board ID</th>
            <th>Name</th>
            <th>Temperature (°C)</th>
            <th>Heart Rate</th>
            <th>Date</th>
        </tr>
        </thead>
    <tbody id="tbody_table_record">
    <?php
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo '<tr>';
            echo '<td>' . $row['id'] . '</td>';
            echo '<td class="bdr">' . $row['username'] . '</td>';
            echo '<td class="bdr">' . $row['temperature'] . '</td>';
            echo '<td class="bdr">' . $row['heart_rate'] . '</td>';
            echo '<td class="bdr">' . $row['date'] . '</td>';
            echo '</tr>';
        }
    } else {
        echo '<tr><td colspan="5">No records found for this user</td></tr>';
    }
    ?>
    </tbody>
</table>
    </table>
    
    <div class="btn-group">
        <button class="button" id="btn_prev" onclick="prevPage()">Prev</button>
        <button class="button" id="btn_next" onclick="nextPage()">Next</button>
        <span>Page: <span id="page"></span></span>
        <select name="number_of_rows" id="number_of_rows">
            <option value="10">10</option>
            <option value="25">25</option>
            <option value="50">50</option>
            <option value="100">100</option>
        </select>
        <button class="button" id="btn_apply" onclick="applyNumberOfRows()">Apply</button>
    </div>
</div>
    <script>
      //------------------------------------------------------------
      var current_page = 1;
      var records_per_page = 10;
      var l = document.getElementById("table_id").rows.length
      //------------------------------------------------------------
      
      //------------------------------------------------------------
      function apply_Number_of_Rows() {
        var x = document.getElementById("number_of_rows").value;
        records_per_page = x;
        changePage(current_page);
      }
      //------------------------------------------------------------
      
      //------------------------------------------------------------
      function prevPage() {
        if (current_page > 1) {
            current_page--;
            changePage(current_page);
        }
      }
      //------------------------------------------------------------
      
      //------------------------------------------------------------
      function nextPage() {
        if (current_page < numPages()) {
            current_page++;
            changePage(current_page);
        }
      }
      //------------------------------------------------------------
      
      //------------------------------------------------------------
      function changePage(page) {
        var btn_next = document.getElementById("btn_next");
        var btn_prev = document.getElementById("btn_prev");
        var listing_table = document.getElementById("table_id");
        var page_span = document.getElementById("page");
       
        // Validate page
        if (page < 1) page = 1;
        if (page > numPages()) page = numPages();

        [...listing_table.getElementsByTagName('tr')].forEach((tr)=>{
            tr.style.display='none'; // reset all to not display
        });
        listing_table.rows[0].style.display = ""; // display the title row

        for (var i = (page-1) * records_per_page + 1; i < (page * records_per_page) + 1; i++) {
          if (listing_table.rows[i]) {
            listing_table.rows[i].style.display = ""
          } else {
            continue;
          }
        }
          
        page_span.innerHTML = page + "/" + numPages() + " (Total Number of Rows = " + (l-1) + ") | Number of Rows : ";
        
        if (page == 0 && numPages() == 0) {
          btn_prev.disabled = true;
          btn_next.disabled = true;
          return;
        }

        if (page == 1) {
          btn_prev.disabled = true;
        } else {
          btn_prev.disabled = false;
        }

        if (page == numPages()) {
          btn_next.disabled = true;
        } else {
          btn_next.disabled = false;
        }
      }
      //------------------------------------------------------------
      
      //------------------------------------------------------------
      function numPages() {
        return Math.ceil((l - 1) / records_per_page);
      }
      //------------------------------------------------------------
      
      //------------------------------------------------------------
      window.onload = function() {
        var x = document.getElementById("number_of_rows").value;
        records_per_page = x;
        changePage(current_page);
      };
      //------------------------------------------------------------
    </script>
  </body>
</html>
