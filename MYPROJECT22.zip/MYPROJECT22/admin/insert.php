<?php
require_once 'db.php';
if(isset($_POST['sendval']) && isset($_POST['sendval2']) && isset($_POST['sendval3']) && isset($_POST['sendval4'])){

    $name = $_POST['sendval4'];
    $boardid = $_POST['sendval3'];
    $heartRate = $_POST['sendval2'];
    $temperature = $_POST['sendval'];


    mysqli_begin_transaction($conn);

    $success = true;

   
    $sql = "SELECT * FROM health_data WHERE id = '$boardid' ";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) > 0) {
        $sql = "UPDATE health_data SET heart_rate = '$heartRate', temperature = '$temperature' WHERE id = '$boardid'";
    } else {
        $sql = "INSERT INTO health_data (id,  heart_rate, temperature) VALUES ('$boardid', '$heartRate', '$temperature')";
    }

    if (!mysqli_query($conn, $sql)) {
        $success = false;
        echo "Error inserting/updating heart rate data in health_data table: " . mysqli_error($conn);
    }
    
 
    $sql1 = "INSERT INTO user_health_record (id,username, heart_rate, temperature) VALUES ('$boardid','$name', '$heartRate', '$temperature')";
    if (!mysqli_query($conn, $sql1)) {
        $success = false;
        echo "Error inserting heart rate data in user_health_record table: " . mysqli_error($conn);
    }

   
    if ($success) {
        mysqli_commit($conn);
        echo "Data inserted/updated successfully in both tables";
    } else {
        mysqli_rollback($conn);
    }

   
    mysqli_close($conn);
}
?>
