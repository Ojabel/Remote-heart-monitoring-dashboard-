

<?php
include("db.php");

if(!empty($_POST['boardid']) && !empty($_POST['username']) && !empty($_POST['password']) && !empty($_POST['email']) && !empty($_POST['contact']) && !empty($_POST['address']) && !empty($_POST['age']) && !empty($_POST['sex']) && !empty($_POST['fname']));
{

$boardid = $_POST['boardid'];
$fname = $_POST['Fname'];
$name = $_POST['username'];
$email = $_POST['email'];
$age = $_POST['age'];
$sex = $_POST['sex'];
$contact = $_POST['contact'];
$address = $_POST['address'];
$image = addslashes(file_get_contents($_FILES['image']['tmp_name'])); 
$pass = $_POST['password'];



    $sql = "INSERT INTO users (Fname,username,password,email,Sex,Age,contact,address,image_data) VALUES ('$fname','$name','$pass','$email','$sex','$age','$contact','$address','$image')";
 
if (mysqli_query($conn, $sql)) {
    echo "Heart rate data inserted/updated successfully";
} else {
    echo "Error inserting/updating heart rate data: " . mysqli_error($conn);
}

$sql = "INSERT INTO user_health_record (id,username) VALUES ('$boardid','$name')";

if (mysqli_query($conn, $sql)) {
    echo "Heart rate data inserted/updated successfully";
} else {
    echo "Error inserting/updating heart rate data: " . mysqli_error($conn);
}



$sql = "INSERT INTO health_data (username) VALUES ('$name')";

if (mysqli_query($conn, $sql)) {
    echo "<script>alert('NEW USER ADDED TO THE SYSTEM')</script>";
    echo "<script>window.location='add_new_user.php'</script>";

} else {
    echo "<script>alert('FAILLED TO ADD NEW USER TO THE SYSTEM')</script>";
    echo "<script>window.location='add_new_user.php'</script>". mysqli_error($conn);
}
}

mysqli_close($conn);

?>




