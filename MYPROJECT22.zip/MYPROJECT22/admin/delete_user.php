<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Decode the JSON data sent from the frontend
    $data = json_decode(file_get_contents("php://input"), true);

        if (isset($data["username"])) {
          $username = $data["username"];

           $conn = new mysqli("localhost", "root", "", "projecttest");

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

         $stmt = $conn->prepare("DELETE FROM users WHERE username = ?");
        $stmt->bind_param("s", $username);

        if ($stmt->execute()) {
              echo "User deleted successfully.";
        } else {
              echo "Error deleting user.";
        }


        $stmt = $conn->prepare("DELETE FROM health_data WHERE username = ?");
        $stmt->bind_param("s", $username);

        if ($stmt->execute()) {
             echo "User deleted successfully.";
        } else {
              echo "Error deleting user.";
        }


        
        $stmt = $conn->prepare("DELETE FROM user_health_record WHERE username = ?");
        $stmt->bind_param("s", $username);

        if ($stmt->execute()) {
              echo "User deleted successfully.";
        } else {
              echo "Error deleting user.";
        }
            $stmt->close();
        $stmt->close();
        $stmt->close();
        $conn->close();
    } else {
           echo "User ID not provided.";
    }
} else {
      echo "Invalid request method.";
}
?>
