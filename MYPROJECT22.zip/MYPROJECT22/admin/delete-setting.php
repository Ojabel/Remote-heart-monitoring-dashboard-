<?php
    include("db.php");

    if(isset($_GET['id'])) { 
        $id = $_GET['id'];
        $query = "DELETE FROM admin WHERE id = $id";
        $result = mysqli_query($conn, $query);
        if(!$result){
            die("Query Failed");

        }
        header('Location: settings.php');
    }
?>