
<?php 

    include "db.php";
    $update = false;
    // adding user
    if (isset($_POST['save-task'])) {
        $name = $_POST['name'];
        $email = $_POST['email'];
        $password = $_POST['password'];
        $query = "INSERT INTO admin(username, email, password) VALUES ('$name', '$email' , '$password')";
        $result = mysqli_query($conn, $query);
        if(!$result) {
          die("Query Failed.");
        } else {echo "Connection Fail".mysqli_connect_error();
    }
        // redirecting
        header('Location: settings.php');
    }

    // update task
    $name = '';
    $email= '';
    $password= '';
    if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $update = true;
    $query = "SELECT * FROM admin WHERE id=$id";
    $result = mysqli_query($conn, $query);
      if (mysqli_num_rows($result) == 1) {
          $row = mysqli_fetch_array($result);
          $name = $row['username'];
          $email = $row['email'];
          $password = $row['password'];
      }
    }

    if (isset($_POST['update'])) {
      $id = $_GET['id'];
      $name= $_POST['username'];
      $email = $_POST['email'];
      $password = $_POST['password'];
      $query = "UPDATE admin set username = '$name', email = '$email', password = '$password' WHERE id=$id";
      mysqli_query($conn, $query);
      $_SESSION['message'] = 'admin Updated Successfully';
      $_SESSION['message_type'] = 'warning';
      header('Location: settings.php');
    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
<style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            
        }
        .nav{
    background-color: #06041d;
    height: 40px;
    width: 100%;
    position: fixed;
   
    top: -5px;
}
        form {
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            background-color: #fff;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
            position: relative;
            left: 100px;
            top: 50px;
        }

        label {
            display: block;
            margin-bottom: 20px;
            position: relative;
            top: 15px;
            color: green;
        }

        input[type="text"], input[type="email"], input[type="number"],
        input[type="password"] {
            width: 100%;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
            margin-bottom: 20px;
        }

        button[type="submit"] {
            width: 100%;
            padding: 10px;
            background-color: #4CAF50;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        button[type="submit"]:hover {
            background-color: #45a049;
        }
        /*table begins*/
      
        table{
            display: grid;
            justify-content: center;
            gap: 10px;
            position: relative;
           left: 6%;
            top: 60px;
        }

    table th, table td {
      padding: 10px;
      border: 1px solid #ddd;
      text-align: center;
    }

    table th {
      background-color: #2a2185;
      color: whitesmoke;
    }

    table tr:hover {
      background-color: #f5f5f5;
    }
    .update{
        background-color: green;
        color: whitesmoke;
        text-decoration: none;
        padding: 5px;
        border-radius: 5px;
    }

    .delete{
        background-color: red;
        color: whitesmoke;
        text-decoration: none;
        padding: 5px;
        border-radius: 5px;
    }

        @media (max-width: 900px) {
        

            .nav{
    background-color: #06041d;
    height: 30px;
    width: 100%;
}
        form {
            max-width: 300px;
            margin: 0 auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            background-color: #fff;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
            position: relative;
            left: 40px;
            top: 30px;
        }
        table  {
            background-color: black;
            color: whitesmoke;
   font-size: x-small;
   margin: 25px;
  
    }
    tr td{
        border: none;
        margin: 10px;
        font-size:small;
      
    }
   

    }



    </style>
   </head>

   <body>
<div class="nav"></div>
    
        <div class="container">
        <?php include 'sidebar.php'; ?>
        

        <div class="formdata">
            
                <form class="" method="POST">
                       
                            <label class="l">Name</label>
                            <input placeholder="Enter Name" name="name" value="<?php echo $name; ?>" type="text" class="form-control">
                    
                            <label class="">Email</label>
                            <input placeholder="Enter Email Address" value="<?php echo $email;?>" name="email" type="email" >
                      
                            <label class="">Password</label>
                            <input placeholder="Enter Password" value="<?php echo $password;?>" name="password" type="password" >
                       
                        <?php if($update == true) { ?>
                        <button class="" type="submit" name="update"> Update </button>
                        <?php } elseif ($update == false) { ?>
                          <button class="" type="submit" name="save-task"> Submit </button>
                        <?php } ?> 
                     </form>
                </div>
                
                <table >
                   
                    <tbody>
                        <?php
                        include("db.php");
                        $query = "SELECT * FROM admin";
                        $result_tasks = mysqli_query($conn, $query);
                    
                        while($row = mysqli_fetch_assoc($result_tasks)) {
                        ?>
                        <tr>
                        
                        <td><?php echo $row['username']; ?></td>
                        <td><?php echo $row['email']; ?></td>
                        <td><?php echo $row['password']; ?></td>
                        <td>
                            <a href="settings.php?id=<?php echo $row['id']?>" class="update">update</a>
                            <a href="delete-setting.php?id=<?php echo $row['id']?>"  class="delete">delete</a>
                        </td>
                        </tr>
                        <?php } ?>
                    </tbody>
                </table>
              
                </div>
            </div>
            
        </div>

     
       

     
        
        </div>
        
       
   </body>

</html>