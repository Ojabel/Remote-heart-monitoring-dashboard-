// Fetch all users' health data
function fetchAllData() {
    fetch('get_all_data.php')
        .then(response => response.json())
        .then(data => {
            document.getElementById('userData').innerHTML = '';
            data.forEach(user => {
                // Create a div for each user's data
                var userDiv = document.createElement('div');
                userDiv.classList.add('user-data');

                // Check if heart rate or temperature exceeds threshold
                var heartRateThreshold = 10; // Example threshold for heart rate
                var temperatureThreshold = 38; // Example threshold for temperature
                var alertMessage = '';
                if (user.heartRate > heartRateThreshold) {
                    alertMessage += `High Heart Rate: ${user.username}'s heart rate is above ${heartRateThreshold}. \n`;
                }
                if (user.temperature > temperatureThreshold) {
                    alertMessage += `High Temperature: ${user.username}'s temperature is above ${temperatureThreshold}. \n`;
                }

                // Add user data to the div
                userDiv.innerHTML = `
                    <img src="${user.icon}" alt="User Icon" class="user-icon">
                    <p>Username: ${user.username}</p>
                    <p>Temperature: ${user.temperature}</p>
                    <p>Heart Rate: ${user.heartRate}</p>
                    <button class="delete-button" onclick="deleteUser('${user.username}')">Delete</button>
                `;

                // Append the user's div to the userData container
                document.getElementById('userData').appendChild(userDiv);

                // If thresholds exceeded, show alert
                if (alertMessage !== '') {
                    window.alert(alertMessage);
                }
            });
        })
        .catch(error => console.error('Error fetching data:', error));
}

  


// Function to delete a user
function deleteUser(userId) {
  // Confirm with the user before deleting
  if (confirm("Are you sure you want to delete this user?")) {
      // Send a DELETE request to delete_user.php
      fetch('delete_user.php', {
          method: 'POST',
          headers: {
              'Content-Type': 'application/json',
          },
          body: JSON.stringify({ userId: userId }),
      })
      .then(response => response.text())
      .then(result => {
          // Display a success message or handle the response
          console.log(result);
          // Refresh the data after deletion
          fetchAllData();
      })
      .catch(error => console.error('Error deleting user:', error));
  }
}

// Refresh data every 5 seconds
setInterval(fetchAllData, 5000);

// Fetch data when the page loads initially
window.onload = fetchAllData;
