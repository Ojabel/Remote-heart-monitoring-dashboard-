<?php
date_default_timezone_set('Africa/Lagos'); // Set the timezone to Nigeria

require_once 'db.php';

$sql = "SELECT id, username, temperature, heart_rate, timeanddate FROM health_data ORDER BY id";
$result = $conn->query($sql);
$data = array();

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $lastUpdateTimestamp = strtotime($row['timeanddate']);
        $currentTime = time();
        $timeDifference = $currentTime - $lastUpdateTimestamp;

        // Determine status based on time difference
        // Set the interval to 300 seconds (5 minutes) for more realistic online/offline status
        $status = ($timeDifference < 15) ? 'Online' : 'Offline';

        $data[] = array(
            'id' => $row['id'],
            'username' => $row['username'],
            'temperature' => $row['temperature'],
            'heartRate' => $row['heart_rate'],
            'status' => $status 
        );
    }

    echo json_encode($data);
} else {
    // No data found
    echo json_encode([]);
}

$conn->close();
?>
