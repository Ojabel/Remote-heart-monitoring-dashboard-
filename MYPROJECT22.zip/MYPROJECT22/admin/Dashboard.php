
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Health Monitoring Dashboard</title>
  <link rel="icon" type="image/png" href="images/bg1.jpg">
  <link rel="stylesheet" href="loader.css">
  
 <link rel="stylesheet" href="Style.css">
  <style>

body {
  font-family: Arial, sans-serif;
  background-image: url('images/bg4.png');
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
 
  position:fixed; 
}
.nav{
    background-color: #06041d;
    height: 40px;
    width: 100%;
    position: fixed;
   
    top: -5px;
}

    h1 {
        text-align: center;
        margin: 20px 0;
        color: #fff;
        background-color: green;
        border-radius: 10px;
    }

    a {
        display: block;
        text-align: center;
        margin-bottom: 20px;
        color: #fff; 
        text-decoration: none;
    }
    

    a:hover {
        color: #f9f9f9;
    }

    .container {
       align-content: center;
        max-width: 80%;
        margin: 0 auto;
        text-align: center;	
        padding: 10px;
        border: 0px solid #ccc;
        border-radius: 5px;
        display: flex;
        justify-content: center;
    }
 
@keyframes fadeIn {
  0% {
      opacity: 0;
      transform: scale(0.9);
  }
  100% {
      opacity: 1;
      transform: scale(1);
  }
}

    #userData {
        display: flex;
        flex-wrap: wrap;
        justify-content: space-between;
        margin-top: 20px;
        animation: fadeIn 1s;
        margin: 0 auto;
        padding: 10px;
        background-color: rgba(255, 255, 255, 0.582);
   margin-top: 50px;
        
    }
        
    .data-card {
        width: calc(20% - 10px); 
        margin: 10px; 
        padding: 20px;
        background-color: #fff;
        border-radius: 10px; 
        box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
        transition: transform 0.3s ease; 
        cursor: pointer;
        border: 1px solid white;
    }

    .data-card:hover {
        transform: translateY(-5px);
        box-shadow: 0px 8px 16px rgba(0, 0, 0, 0.2);
    }

    .data-card h2 {
        font-size: 20px; 
        margin-bottom: 10px;
        color: #333;
    }

    .data-card p {
        font-size: 16px;
        margin-bottom: 5px; 
        color: #666; 
    }

    .data-card button {
        padding: 8px 16px; 
        background-color: #4CAF50; 
        border: none; 
        color: white; 
        font-size: 14px; 
        border-radius: 5px;
        transition: background-color 0.3s; 
    }

    .data-card button:hover {
        background-color: #45a049; 
    }
    .delete-button{
      margin-bottom: 5px;
     
    }
    .above-threshold .data-card {
        border-color: red;
}

.prpix{
    width: 100px;
}

@media (max-width: 390px) {
    .container {
        float: right;
        display: flex;
        flex-wrap: wrap;
        position: relative;
        right: 25px;
    }
    .nav{
    width: 120%;
}
 
    .prpix{
        position: relative;
        top: -40px;
        right: 20px;
}


}
@media (max-width: 450px) {
    .data-card {
        width: calc(45% - 10px); 
    
    }

    .container {
        float:right;
        display: flex;
        flex-wrap: wrap;
        position: relative;
        right: 25px;
    }
  
    .nav{
    width: 120%;
}
    
 
    #userData {
        display: flex;
        flex-wrap: wrap;   
        animation: fadeIn 1s;
        max-width: 110%;
        margin: 0 auto;
        padding: 0px;
        margin-top: 11%;
        position: relative;
        right: -7%;
       
    }
    .prpix{
        position: relative;
        top: -40px;
}
p{
    position: relative;
        top: -60px;
}
        .button-row{
            position: relative;
            top: -60px;
        }
  
        }

  

</style>
  

  <?php include("sidebar.php") ?>
</head>

<body>


 
  <div class="loader "></div>
  <div class="container" id="userData"></div>
  <div class="nav"></div>
  <script>
    function fetchAllData() {
    fetch('get_all_data.php')
        .then(response => response.json())
        .then(data => {
            document.getElementById('userData').innerHTML = '';
            data.forEach(user => {
                // Create a div for each user's data
                var userDiv = document.createElement('div');
                userDiv.classList.add('data-card');

                // Set status color based on online or offline
                var statusColor = user.status === 'Online' ? 'green' : 'red';

                 // Check if heart rate or temperature exceeds threshold
                 var heartRateThreshold = 90; // Example threshold for heart rate
                var temperatureThreshold = 38; // Example threshold for temperature
                var alertMessage = '';
                if (user.heartRate > heartRateThreshold) {
                    alertMessage += `High Heart Rate: ${user.username}'s heart rate is above ${heartRateThreshold}. \n`;
                }
                if (user.temperature > temperatureThreshold) {
                    alertMessage += `High Temperature: ${user.username}'s temperature is above ${temperatureThreshold}. \n`;
                }
                // Add user data to the div

                userDiv.innerHTML = `
                    <h2>${user.username}</h2>
                    <img src="images/hrtbt.png" class="prpix">
                    <p>Temperature: ${user.temperature}</p>
                    <p>Heart Rate: ${user.heartRate}</p>
                    <p>Status: <span style="color: ${statusColor};">${user.status}</span></p>
                    <div class="button-row">
                        <button class="delete-button" onclick="deleteUser('${user.username}')">Delete</button>
                        <button class="view-button" onclick="viewRecord('${user.username}')">View Record</button>
                    </div>
                `;

                document.getElementById('userData').appendChild(userDiv);
                if (alertMessage !== '') {
                    window.alert(alertMessage);
                }
            });
        })
        .catch(error => console.error('Error fetching data:', error));
}

setInterval(fetchAllData, 5000); // Fetch data every 5 seconds
window.onload = fetchAllData;

    function deleteUser(username) {
        if (confirm("Are you sure you want to delete this user?")) {
            fetch('delete_user.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ username:username }),
            })
            .then(response => response.text())
            .then(result => {
                console.log(result);
                fetchAllData();
            })
            .catch(error => console.error('Error deleting user:', error));
        }
    }

   

            function viewRecord(username) {
           
                window.location.href = `view_user_record.php?username=${username}`;
            }


   // setInterval(fetchAllData, 5000);
    //window.onload = fetchAllData;
</script>

<script>
    window.addEventListener("load", () =>{
        const loader = document.querySelector(".loader");
    loader.classList.add("loader--hidden");
    loader.addEventListener("transitinend", () =>{
        document.body.removeChild(loader);
    })
 });
</script>

</body>
</html>
